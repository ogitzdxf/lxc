import psutil
import os
import signal

def stop_bot():
    print("🔍 Searching for running SVM Bot...")
    found = False
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            # Check if 'bot.py' is in the command line arguments
            cmdline = proc.info.get('cmdline')
            if cmdline and any('bot.py' in arg for arg in cmdline):
                print(f"🛑 Found SVM Bot (PID: {proc.info['pid']}). Stopping...")
                proc.send_signal(signal.SIGTERM) # Try to stop gracefully
                found = True
                print("✅ Bot has been stopped successfully.")
                break
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    
    if not found:
        print("ℹ️ No running SVM Bot was found.")

if __name__ == "__main__":
    stop_bot()
