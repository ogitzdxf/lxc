from __future__ import annotations

import sys

if sys.version_info >= (3, 13):
    try:
        import audioop
    except ImportError:
        try:
            import audioop_lts
            sys.modules["audioop"] = audioop_lts
        except ImportError:
            pass # Voice support will be disabled


import asyncio
import datetime as dt
import hashlib
import hmac
import json
import logging
import os
import random
import secrets
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Literal

import aiohttp
import aiosqlite
import discord
from cryptography.fernet import Fernet
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="[%(asctime)s] %(levelname)s %(name)s: %(message)s",
    )


log = logging.getLogger("tc.main")


MAIN_FOLDERS = [
    "embeds",
    "assets",
    "backups",
    "cache",
    "logs",
    "temp",
    "generated_passwords",
]

ASSET_FILES = [
    "banner.png",
    "loading.gif",
    "success.png",
    "error.png",
    "node_online.png",
    "node_offline.png",
    "warning.png",
]


def ensure_main_folders() -> None:
    for d in MAIN_FOLDERS:
        os.makedirs(d, exist_ok=True)
    for name in ASSET_FILES:
        path = os.path.join("assets", name)
        if not os.path.exists(path):
            open(path, "ab").close()


def utcnow_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _base64_urlsafe(raw: bytes) -> bytes:
    import base64

    return base64.urlsafe_b64encode(raw)


def get_fernet(api_secret: str, fernet_key_env: str | None) -> Fernet:
    if fernet_key_env and fernet_key_env.strip():
        return Fernet(fernet_key_env.strip().encode("ascii"))
    digest = hashlib.sha256(api_secret.encode("utf-8")).digest()
    return Fernet(_base64_urlsafe(digest))


def encrypt_text(fernet: Fernet, value: str) -> str:
    return fernet.encrypt(value.encode("utf-8")).decode("ascii")


def decrypt_text(fernet: Fernet, value: str) -> str:
    return fernet.decrypt(value.encode("utf-8")).decode("utf-8")


@dataclass
class SQLiteDB:
    path: str
    conn: aiosqlite.Connection | None = None
    lock: asyncio.Lock | None = None

    async def open(self) -> None:
        self.conn = await aiosqlite.connect(self.path, timeout=30)
        self.conn.row_factory = aiosqlite.Row
        self.lock = asyncio.Lock()
        await self.conn.execute("PRAGMA journal_mode=WAL;")
        await self.conn.execute("PRAGMA synchronous=NORMAL;")
        await self.conn.execute("PRAGMA foreign_keys=ON;")
        await self.conn.execute("PRAGMA temp_store=MEMORY;")
        await self.conn.execute("PRAGMA busy_timeout=5000;")
        await self.conn.commit()

    async def close(self) -> None:
        if self.conn:
            await self.conn.close()
        self.conn = None
        self.lock = None

    async def execute(self, sql: str, params: tuple[Any, ...] = ()) -> aiosqlite.Cursor:
        assert self.conn and self.lock
        async with self.lock:
            return await self.conn.execute(sql, params)

    async def fetchone(self, sql: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        cur = await self.execute(sql, params)
        async with cur:
            row = await cur.fetchone()
            return dict(row) if row else None

    async def fetchall(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        cur = await self.execute(sql, params)
        async with cur:
            rows = await cur.fetchall()
            return [dict(r) for r in rows]

    async def commit(self) -> None:
        assert self.conn and self.lock
        async with self.lock:
            await self.conn.commit()


async def migrate(db: SQLiteDB, logs_db: SQLiteDB) -> None:
    await db.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER NOT NULL, applied_at TEXT NOT NULL);")
    await logs_db.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER NOT NULL, applied_at TEXT NOT NULL);")
    await db.commit()
    await logs_db.commit()

    row = await db.fetchone("SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1;")
    v = int(row["version"]) if row else 0
    if v < 1:
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS users(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              discord_id TEXT NOT NULL UNIQUE,
              created_at TEXT NOT NULL,
              is_admin INTEGER NOT NULL DEFAULT 0,
              suspended INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_discord_id ON users(discord_id);")
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS nodes(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL UNIQUE,
              ipv4 TEXT NOT NULL,
              port INTEGER NOT NULL,
              secret_enc TEXT NOT NULL,
              ram_total INTEGER NOT NULL DEFAULT 0,
              ram_used INTEGER NOT NULL DEFAULT 0,
              cpu_total INTEGER NOT NULL DEFAULT 0,
              cpu_used INTEGER NOT NULL DEFAULT 0,
              disk_total INTEGER NOT NULL DEFAULT 0,
              disk_used INTEGER NOT NULL DEFAULT 0,
              location TEXT NOT NULL DEFAULT 'unknown',
              max_vps INTEGER NOT NULL DEFAULT 0,
              status TEXT NOT NULL DEFAULT 'unknown',
              last_check_at TEXT
            );
            """
        )
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_nodes_ip_port ON nodes(ipv4, port);")
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS vps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                container_name TEXT UNIQUE,
                owner_id INTEGER,
                node_id INTEGER,
                template TEXT,
                ipv4 TEXT,
                ssh_port INTEGER,
                ram INTEGER,
                cpu INTEGER,
                disk INTEGER,
                status TEXT,
                password_enc TEXT,
                created_at TEXT
            );
            """
        )
        # Migration for existing databases
        try:
            await db.conn.execute("ALTER TABLE vps ADD COLUMN template TEXT;")
        except Exception:
            pass
        try:
            await db.conn.execute("ALTER TABLE vps ADD COLUMN password_enc TEXT;")
        except Exception:
            pass
        await db.execute("CREATE INDEX IF NOT EXISTS idx_vps_owner_id ON vps(owner_id);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_vps_node_id ON vps(node_id);")
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS ports(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              vps_id INTEGER NOT NULL,
              node_id INTEGER NOT NULL,
              external_port INTEGER NOT NULL,
              internal_port INTEGER NOT NULL,
              protocol TEXT NOT NULL,
              created_at TEXT NOT NULL,
              UNIQUE(node_id, external_port, protocol)
            );
            """
        )
        await db.execute("CREATE INDEX IF NOT EXISTS idx_ports_vps_id ON ports(vps_id);")
        await db.execute("INSERT INTO schema_migrations(version, applied_at) VALUES(1, ?);", (utcnow_iso(),))
        await db.commit()

    row = await logs_db.fetchone("SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1;")
    lv = int(row["version"]) if row else 0
    if lv < 1:
        await logs_db.execute(
            """
            CREATE TABLE IF NOT EXISTS audit_logs(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts TEXT NOT NULL,
              actor_discord_id TEXT NOT NULL,
              action TEXT NOT NULL,
              details TEXT NOT NULL
            );
            """
        )
        await logs_db.execute("CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_logs(ts);")
        await logs_db.execute("CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);")
        await logs_db.execute("INSERT INTO schema_migrations(version, applied_at) VALUES(1, ?);", (utcnow_iso(),))
        await logs_db.commit()


async def get_or_create_user(db: SQLiteDB, discord_id: int) -> dict[str, Any]:
    row = await db.fetchone("SELECT * FROM users WHERE discord_id=?;", (str(discord_id),))
    if row:
        return row
    await db.execute("INSERT INTO users(discord_id, created_at, is_admin, suspended) VALUES(?, ?, 0, 0);", (str(discord_id), utcnow_iso()))
    await db.commit()
    return await db.fetchone("SELECT * FROM users WHERE discord_id=?;", (str(discord_id),)) or {}


async def audit(logs_db: SQLiteDB, *, actor_id: int, action: str, details: str) -> None:
    await logs_db.execute("INSERT INTO audit_logs(ts, actor_discord_id, action, details) VALUES(?, ?, ?, ?);", (utcnow_iso(), str(actor_id), action, details))


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sign(secret: str, timestamp: int, nonce: str, method: str, path: str, body_sha256: str) -> str:
    msg = f"{timestamp}.{nonce}.{method.upper()}.{path}.{body_sha256}".encode("utf-8")
    return hmac.new(secret.encode("utf-8"), msg, hashlib.sha256).hexdigest()


def new_nonce() -> str:
    return secrets.token_urlsafe(18)


async def signed_json_request(
    session: aiohttp.ClientSession,
    *,
    base_url: str,
    secret: str,
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    query: dict[str, str] | None = None,
    timeout_seconds: int = 30,
) -> Any:
    body = b""
    if payload is not None:
        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    url = base_url.rstrip("/") + path
    if query:
        url = str(aiohttp.client.URL(url).with_query(query))
    ts = int(time.time())
    nonce = new_nonce()
    signature = sign(secret, ts, nonce, method, path, sha256_hex(body))
    headers = {
        "X-TC-Timestamp": str(ts),
        "X-TC-Nonce": nonce,
        "X-TC-Signature": signature,
        "Content-Type": "application/json",
    }
    timeout = aiohttp.ClientTimeout(total=timeout_seconds)
    async with session.request(method.upper(), url, data=body if body else None, headers=headers, timeout=timeout) as resp:
        text = await resp.text()
        if resp.status >= 400:
            raise RuntimeError(f"node_http_error {resp.status}: {text[:300]}")
        return json.loads(text) if text else None


class NodeClient:
    def __init__(self, session: aiohttp.ClientSession) -> None:
        self._session = session

    async def health(self, base_url: str) -> dict[str, Any]:
        async with self._session.get(base_url.rstrip("/") + "/health", timeout=aiohttp.ClientTimeout(total=10)) as resp:
            return await resp.json()

    async def resources(self, *, base_url: str, secret: str) -> dict[str, Any]:
        return await signed_json_request(self._session, base_url=base_url, secret=secret, method="GET", path="/resources")

    async def create(self, *, base_url: str, secret: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await signed_json_request(self._session, base_url=base_url, secret=secret, method="POST", path="/create", payload=payload, timeout_seconds=600)

    async def action(self, *, base_url: str, secret: str, path: str, container_name: str) -> dict[str, Any]:
        return await signed_json_request(self._session, base_url=base_url, secret=secret, method="POST", path=path, payload={"container_name": container_name})

    async def port_add(self, *, base_url: str, secret: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await signed_json_request(self._session, base_url=base_url, secret=secret, method="POST", path="/ports/add", payload=payload)

    async def port_remove(self, *, base_url: str, secret: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await signed_json_request(self._session, base_url=base_url, secret=secret, method="POST", path="/ports/remove", payload=payload)

    async def ssh_reset(self, *, base_url: str, secret: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await signed_json_request(self._session, base_url=base_url, secret=secret, method="POST", path="/ssh/reset", payload=payload, timeout_seconds=120)


@dataclass
class QueueTask:
    task_id: str
    node_id: int
    user_id: int
    name: str
    runner: Callable[[], Awaitable[object]]
    future: asyncio.Future[object] | None = None


class TaskQueue:
    def __init__(self, *, global_concurrency: int, per_node_concurrency: int) -> None:
        self._queue: asyncio.Queue[QueueTask] = asyncio.Queue()
        self._workers: list[asyncio.Task[None]] = []
        self._global = asyncio.Semaphore(global_concurrency)
        self._per_node = per_node_concurrency
        self._node_sems: dict[int, asyncio.Semaphore] = {}

    def pending(self) -> int:
        return self._queue.qsize()

    async def start(self, workers: int = 10) -> None:
        for i in range(workers):
            self._workers.append(asyncio.create_task(self._worker(i)))

    async def stop(self) -> None:
        for w in self._workers:
            w.cancel()
        self._workers.clear()

    async def submit(self, task: QueueTask) -> object:
        if task.future is None:
            task.future = asyncio.get_running_loop().create_future()
        await self._queue.put(task)
        return await task.future

    def _node_sem(self, node_id: int) -> asyncio.Semaphore:
        if node_id not in self._node_sems:
            self._node_sems[node_id] = asyncio.Semaphore(self._per_node)
        return self._node_sems[node_id]

    async def _worker(self, idx: int) -> None:
        while True:
            t = await self._queue.get()
            try:
                async with self._global:
                    async with self._node_sem(t.node_id):
                        try:
                            res = await t.runner()
                            if t.future and not t.future.done():
                                t.future.set_result(res)
                        except Exception as e:
                            if t.future and not t.future.done():
                                t.future.set_exception(e)
                            log.exception("queue_task_failed", extra={"task_id": t.task_id, "name": t.name})
            finally:
                self._queue.task_done()


@dataclass(frozen=True)
class Theme:
    color: discord.Color = discord.Color.from_rgb(255, 255, 255) # White Minimalism
    footer: str = "TC NEXT-GEN • SECURED CLOUD"
    banner: str = "https://s1.ezgif.com/tmp/ezgif-11e3d19fe3c4d4ba.gif" # Tech Banner PNG
    loading: str = "https://i.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3NidXU4Ynh6Z3p5Z3p5Z3p5Z3p5Z3p5Z3p5Z3p5Z3p5Z3p5JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/u04bLMEmZ08o37p00t/giphy.gif"
    icon: str = "https://s1.ezgif.com/tmp/ezgif-11e3d19fe3c4d4ba.gif"

class Emojis:
    # White Custom Style
    SYS = "✧"
    DOT = "◈"
    HEX = "⬢"
    PLUS = "✦"
    CMD = "◇"
    CLOUD = "☁️"
    NODE = "📡"
    VPS = "🖥️"
    POWER = "⚡"
    ON = "⚪"
    OFF = "⚫"
    WAIT = "⏳"
    KEY = "🔑"
    USER = "👤"
    STATS = "📈"
    GEAR = "⚙️"
    SHIELD = "🛡️"
    LINK = "🔗"
    ERROR = "❌"
    SUCCESS = "✅"

def neon_embed(theme: Theme, *, title: str, description: str = "", thumbnail: str | None = None) -> discord.Embed:
    e = discord.Embed(title=f"{Emojis.SYS} {title}", description=description, color=theme.color, timestamp=dt.datetime.now(dt.timezone.utc))
    e.set_footer(text=theme.footer)
    if thumbnail:
        e.set_thumbnail(url=thumbnail)
    return e

class ManageView(discord.ui.View):
    def __init__(self, rt: Runtime, vps_name: str, owner_id: int):
        super().__init__(timeout=180)
        self.rt = rt
        self.vps_name = vps_name
        self.owner_id = owner_id

    async def _action(self, interaction: discord.Interaction, action: str):
        if str(interaction.user.id) != str(self.owner_id):
            await interaction.response.send_message("You do not own this VPS.", ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        vps = await self.rt.db.fetchone("SELECT * FROM vps WHERE container_name=?;", (self.vps_name,))
        node = await self.rt.db.fetchone("SELECT * FROM nodes WHERE id=?;", (int(vps["node_id"]),))
        secret = decrypt_text(self.rt.fernet, node["secret_enc"])
        
        async def runner():
            return await self.rt.node_client.action(base_url=base_url(node), secret=secret, container_name=self.vps_name, action=action)
        
        qt = QueueTask(task_id=task_id(), node_id=int(node["id"]), user_id=int(interaction.user.id), name=f"vps_{action}", runner=runner)
        await self.rt.queue.submit(qt)
        await self.rt.db.execute("UPDATE vps SET status=? WHERE container_name=?;", ("running" if action in ["start", "restart"] else "stopped", self.vps_name))
        await self.rt.db.commit()
        await interaction.followup.send(f"Successfully {action}ed `{self.vps_name}`.", ephemeral=True)

    @discord.ui.button(label="START", style=discord.ButtonStyle.success, emoji="🟢")
    async def start_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._action(interaction, "start")

    @discord.ui.button(label="STOP", style=discord.ButtonStyle.danger, emoji="🔴")
    async def stop_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._action(interaction, "stop")

    @discord.ui.button(label="RESTART", style=discord.ButtonStyle.secondary, emoji="🔁")
    async def restart_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._action(interaction, "restart")

class AccessView(discord.ui.View):
    def __init__(self, theme: Theme, ip: str, port: int, password: str):
        super().__init__(timeout=None)
        self.theme = theme
        self.ip = ip
        self.port = port
        self.password = password

    @discord.ui.button(label="Access Credentials", style=discord.ButtonStyle.secondary, emoji="🔑")
    async def access(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Only the user receiving the VPS should see this? 
        # Actually, let's keep it ephemeral so anyone who can click it sees their own view if permitted.
        # But per the user's request, show details.
        msg = f"**{Emojis.LINK} Connection Details**\n"
        msg += f"> IP: `{self.ip}`\n"
        msg += f"> Port: `{self.port}`\n"
        msg += f"> User: `root`\n"
        msg += f"> Pass: `{self.password}`\n\n"
        msg += f"*Connect via:* `ssh root@{self.ip} -p {self.port}`"
        await interaction.response.send_message(msg, ephemeral=True)


def error_embed(theme: Theme, message: str) -> discord.Embed:
    e = discord.Embed(title=f"{Emojis.ERROR} TC ERROR", description=f"```ansi\n\u001b[2;31m{message}\u001b[0m\n```", color=discord.Color.red())
    e.set_footer(text=theme.footer)
    return e


def success_embed(theme: Theme, title: str, message: str) -> discord.Embed:
    e = neon_embed(theme, title=f"{Emojis.SUCCESS} {title}", description=f"```ansi\n\u001b[2;32m{message}\u001b[0m\n```")
    return e


def loading_embed(theme: Theme, title: str, message: str) -> discord.Embed:
    e = discord.Embed(title=f"{Emojis.WAIT} {title} • PROCESSING", description=f"```ansi\n\u001b[2;34m{message}\u001b[0m\n```", color=theme.color)
    e.set_thumbnail(url=theme.loading)
    e.set_footer(text=theme.footer)
    return e


class CreateModal(discord.ui.Modal, title="TC VPS Create"):
    ram = discord.ui.TextInput(label="RAM (MB)", placeholder="2048", min_length=1, max_length=6)
    cpu = discord.ui.TextInput(label="CPU Cores", placeholder="2", min_length=1, max_length=3)
    disk = discord.ui.TextInput(label="Disk (GB)", placeholder="20", min_length=1, max_length=5)

    def __init__(self, view: "CreateView"):
        super().__init__(timeout=180)
        self._view = view

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            self._view.ram_mb = int(str(self.ram))
            self._view.cpu_cores = int(str(self.cpu))
            self._view.disk_gb = int(str(self.disk))
        except ValueError:
            await interaction.response.send_message(embed=error_embed(self._view.theme, "Invalid numeric values."), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        await self._view.refresh_followup(interaction)


class NodeSelect(discord.ui.Select):
    def __init__(self, options: list[discord.SelectOption]):
        super().__init__(placeholder="Select Node", options=options, min_values=1, max_values=1, row=0)

    async def callback(self, interaction: discord.Interaction) -> None:
        view: CreateView = self.view  # type: ignore[assignment]
        if self.values and self.values[0] != "0":
            view.node_id = int(self.values[0])
        await view.refresh(interaction)


class TemplateSelect(discord.ui.Select):
    def __init__(self, templates: list[str]):
        opts = [discord.SelectOption(label=t, value=t) for t in templates[:25]]
        super().__init__(placeholder="Select OS Template", options=opts, min_values=1, max_values=1, row=1)

    async def callback(self, interaction: discord.Interaction) -> None:
        view: CreateView = self.view  # type: ignore[assignment]
        if self.values:
            view.template = self.values[0]
        await view.refresh(interaction)


class SetResourcesButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Set Resources", style=discord.ButtonStyle.secondary, row=2)

    async def callback(self, interaction: discord.Interaction) -> None:
        view: CreateView = self.view  # type: ignore[assignment]
        await interaction.response.send_modal(CreateModal(view))


class CreateButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Create VPS", style=discord.ButtonStyle.primary, disabled=True, row=2)

    async def callback(self, interaction: discord.Interaction) -> None:
        view: CreateView = self.view  # type: ignore[assignment]
        await interaction.response.edit_message(embed=loading_embed(view.theme, "TC VPS CREATE", "Queued..."), view=None)
        await view.on_create(interaction)


class HelpView(discord.ui.View):
    def __init__(self, theme: Theme):
        super().__init__(timeout=120)
        self.theme = theme

    @discord.ui.select(
        placeholder="Select Command Category...",
        options=[
            discord.SelectOption(label="Cloud Management", value="vps", emoji="🖥️", description="Create and manage your virtual machines."),
            discord.SelectOption(label="System Admin", value="admin", emoji="🛰️", description="Node and infrastructure management."),
            discord.SelectOption(label="Utility Tools", value="tools", emoji="⚙️", description="Port mapping, stats, and network tools."),
            discord.SelectOption(label="Fun & Social", value="fun", emoji="🎮", description="Crypto, games, and entertainment."),
        ]
    )
    async def select_category(self, interaction: discord.Interaction, select: discord.ui.Select):
        cat = select.values[0]
        e = neon_embed(self.theme, title=f"TC • {cat.upper()} COMMANDS")
        
        if os.path.exists("banner.jpg"):
            e.set_image(url="attachment://banner.jpg")
        else:
            e.set_thumbnail(url=self.theme.banner)
        
        if cat == "vps":
            e.description = "✧ `/create` - Provision a new VPS\n✧ `/myvps` - List your instances\n✧ `/manage` - Dashboard for VPS actions\n✧ `/ssh` - Get login credentials\n✧ `/resetpass` - Reset root password"
        elif cat == "admin":
            e.description = "✧ `/node add` - Register a new node\n✧ `/node list` - View network nodes\n✧ `/status` - Check queue and bot status\n✧ `/suspend` - Disable a user's access\n✧ `/unsuspend` - Enable a user's access"
        elif cat == "tools":
            e.description = "✧ `/port add` - Map a custom port\n✧ `/port list` - View port mappings\n✧ `/port random` - Generate random mapping\n✧ `/stats` - View node resource usage\n✧ `/ping` - Check system latency"
        elif cat == "fun":
            e.description = "✧ `/crypto` - Track BTC/ETH prices\n✧ `/coinflip` - Flip a coin\n✧ `/roll` - Roll a dice\n✧ `/calc` - Advanced calculator\n✧ `/server` - Discord server info\n✧ `/user` - User profile info"
        
        await interaction.response.edit_message(embed=e, view=self)

class CreateView(discord.ui.View):
    def __init__(self, *, rt: "Runtime", theme: Theme, node_options: list[discord.SelectOption], templates: list[str], on_create_cb):
        super().__init__(timeout=300)
        self.rt = rt
        self.theme = theme
        self._on_create_cb = on_create_cb
        self.message_id: int | None = None
        self.node_id: int | None = None
        self.template: str | None = None
        self.ram_mb: int | None = None
        self.cpu_cores: int | None = None
        self.disk_gb: int | None = None
        self._create_btn = CreateButton()
        self.add_item(NodeSelect(node_options))
        self.add_item(TemplateSelect(templates))
        self.add_item(SetResourcesButton())
        self.add_item(self._create_btn)

    async def refresh(self, interaction: discord.Interaction) -> None:
        ready = all([self.node_id, self.template, self.ram_mb, self.cpu_cores, self.disk_gb])
        self._create_btn.disabled = not ready
        e = neon_embed(self.theme, title=f"{Emojis.CLOUD} TC • VPS CONFIGURATOR", description="Tailor your virtual machine instance below.")
        e.add_field(name=f"{Emojis.NODE} Target Node", value=f"> `{self.node_id or 'Selection Required'}`", inline=True)
        e.add_field(name=f"{Emojis.GEAR} OS Template", value=f"> `{self.template or 'Selection Required'}`", inline=True)
        res_val = f"> {Emojis.STATS} **RAM**: `{self.ram_mb or '?'}` MB\n> {Emojis.POWER} **CPU**: `{self.cpu_cores or '?'}` Cores\n> {Emojis.SHIELD} **Disk**: `{self.disk_gb or '?'}` GB"
        e.add_field(name=f"{Emojis.STATS} Resource Allocation", value=res_val, inline=False)
        await interaction.response.edit_message(embed=e, view=self)

    async def refresh_followup(self, interaction: discord.Interaction) -> None:
        if not self.message_id:
            return
        ready = all([self.node_id, self.template, self.ram_mb, self.cpu_cores, self.disk_gb])
        self._create_btn.disabled = not ready
        e = neon_embed(self.theme, title=f"{Emojis.CLOUD} TC • VPS CONFIGURATOR", description="Tailor your virtual machine instance below.")
        e.add_field(name=f"{Emojis.NODE} Target Node", value=f"> `{self.node_id or 'Selection Required'}`", inline=True)
        e.add_field(name=f"{Emojis.GEAR} OS Template", value=f"> `{self.template or 'Selection Required'}`", inline=True)
        res_val = f"> {Emojis.STATS} **RAM**: `{self.ram_mb or '?'}` MB\n> {Emojis.POWER} **CPU**: `{self.cpu_cores or '?'}` Cores\n> {Emojis.SHIELD} **Disk**: `{self.disk_gb or '?'}` GB"
        e.add_field(name=f"{Emojis.STATS} Resource Allocation", value=res_val, inline=False)
        await interaction.followup.edit_message(message_id=self.message_id, embed=e, view=self)

    async def on_create(self, interaction: discord.Interaction) -> None:
        await self._on_create_cb(interaction, self)


def generate_container_name(prefix: str = "tc") -> str:
    return f"{prefix}{random.randint(1000000, 9999999)}"


def base_url(node: dict[str, Any]) -> str:
    return f"http://{node['ipv4']}:{node['port']}"


def task_id() -> str:
    return secrets.token_hex(8)


@dataclass
class Runtime:
    owner_id: int
    theme: Theme
    api_secret: str
    fernet: Fernet
    http: aiohttp.ClientSession
    node_client: NodeClient
    queue: TaskQueue
    db: SQLiteDB
    logs: SQLiteDB
    queue_limit: int
    max_create_queue: int
    default_port_slots: int
    password_length: int
    default_template: str
    enable_audit: bool


class TC Bot(commands.Bot):
    def __init__(self, rt: Runtime):
        intents = discord.Intents.none()
        intents.guilds = True
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents)
        self.rt = rt

    async def setup_hook(self) -> None:
        await self.rt.queue.start(workers=10)
        self.tree.on_error = self._on_app_command_error  # type: ignore[assignment]
        self.loop.create_task(self._node_verify_loop())
        await self.tree.sync()

    async def close(self) -> None:
        await self.rt.queue.stop()
        await self.rt.http.close()
        await self.rt.db.close()
        await self.rt.logs.close()
        await super().close()

    async def _on_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
        log.exception("app_command_error", extra={"cmd": getattr(interaction.command, "name", "unknown")})
        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=error_embed(self.rt.theme, str(error)), ephemeral=True)
            else:
                await interaction.response.send_message(embed=error_embed(self.rt.theme, str(error)), ephemeral=True)
        except Exception:
            pass

    async def _node_verify_loop(self) -> None:
        await self.wait_until_ready()
        while not self.is_closed():
            try:
                nodes = await self.rt.db.fetchall("SELECT * FROM nodes;")
                for n in nodes:
                    status = "offline"
                    try:
                        h = await self.rt.node_client.health(base_url(n))
                        status = "online" if bool(h.get("ok")) else "offline"
                    except Exception:
                        status = "offline"
                    await self.rt.db.execute("UPDATE nodes SET status=?, last_check_at=? WHERE id=?;", (status, utcnow_iso(), int(n["id"])))
                await self.rt.db.commit()
            except Exception:
                log.exception("node_verify_loop_failed")
            await asyncio.sleep(30)


async def build_node_options(rt: Runtime) -> list[discord.SelectOption]:
    nodes = await rt.db.fetchall("SELECT * FROM nodes ORDER BY name ASC;")
    if not nodes:
        return [discord.SelectOption(label="No nodes available", value="0", description="Add a node first.")]
    opts: list[discord.SelectOption] = []
    for n in nodes[:25]:
        label = f"{n['name']} [{n['status']}]"
        opts.append(discord.SelectOption(label=label[:100], value=str(n["id"]), description=f"{n['ipv4']}:{n['port']} • {n['location']}"[:100]))
    return opts


def main() -> None:
    load_dotenv(override=False)
    ensure_main_folders()

    token = (os.getenv("TOKEN") or "").strip()
    if not token:
        raise RuntimeError("TOKEN is required in main_bot/.env")
    owner_id = int((os.getenv("BOT_OWNER_ID") or "0").strip() or "0")
    api_secret = (os.getenv("API_SECRET") or "").strip()
    if not api_secret:
        raise RuntimeError("API_SECRET is required in main_bot/.env")

    embed_color = int((os.getenv("EMBED_COLOR") or "0xB026FF").strip(), 0)
    log_level = (os.getenv("LOG_LEVEL") or "INFO").strip()
    configure_logging(log_level)

    queue_limit = int((os.getenv("QUEUE_LIMIT") or "50").strip() or "50")
    max_create_queue = int((os.getenv("MAX_CREATE_QUEUE") or "200").strip() or "200")
    default_port_slots = int((os.getenv("DEFAULT_PORT_SLOTS") or "30").strip() or "30")
    password_length = int((os.getenv("PASSWORD_LENGTH") or "12").strip() or "12")
    default_template = (os.getenv("DEFAULT_TEMPLATE") or "ubuntu:24.04").strip()
    enable_audit = (os.getenv("ENABLE_AUDIT_LOGS") or "true").strip().lower() in {"1", "true", "yes", "on"}

    fernet = get_fernet(api_secret, os.getenv("TC_FERNET_KEY"))

    async def runner() -> None:
        db = SQLiteDB("svm.db")
        logs_db = SQLiteDB("logs.db")
        await db.open()
        await logs_db.open()
        await migrate(db, logs_db)

        http = aiohttp.ClientSession()
        rt = Runtime(
            owner_id=owner_id,
            theme=Theme(color=discord.Color(embed_color)),
            api_secret=api_secret,
            fernet=fernet,
            http=http,
            node_client=NodeClient(http),
            queue=TaskQueue(global_concurrency=queue_limit, per_node_concurrency=4),
            db=db,
            logs=logs_db,
            queue_limit=queue_limit,
            max_create_queue=max_create_queue,
            default_port_slots=default_port_slots,
            password_length=password_length,
            default_template=default_template,
            enable_audit=enable_audit,
        )

        bot = TCBot(rt)

        node_group = app_commands.Group(name="node", description="Node management")
        port_group = app_commands.Group(name="port", description="Port forwarding")
        admin_group = app_commands.Group(name="admin", description="Admin tools")
        bot.tree.add_command(node_group)
        bot.tree.add_command(port_group)
        bot.tree.add_command(admin_group)

        def _is_admin(interaction: discord.Interaction, user: dict[str, Any]) -> bool:
            if interaction.user and interaction.user.id == rt.owner_id and rt.owner_id:
                return True
            if interaction.guild and interaction.user and interaction.user.guild_permissions.administrator:
                return True
            return bool(int(user.get("is_admin") or 0))

        async def _ensure_deferred(interaction: discord.Interaction) -> None:
            if not interaction.response.is_done():
                await interaction.response.defer(ephemeral=True)

        async def _get_owned_vps(discord_id: int, name: str) -> dict[str, Any] | None:
            user = await get_or_create_user(rt.db, discord_id)
            return await rt.db.fetchone("SELECT * FROM vps WHERE owner_id=? AND container_name=?;", (int(user["id"]), name))

        @bot.tree.command(name="help", description="Next-Gen Help Menu")
        async def help_cmd(interaction: discord.Interaction) -> None:
            e = neon_embed(rt.theme, title="TC NEXT-GEN • CONTROL CENTER", description="Welcome to the future of cloud management. Select a category below to explore available modules.")
            view = HelpView(rt.theme)
            
            if os.path.exists("banner.jpg"):
                file = discord.File("banner.jpg", filename="banner.jpg")
                e.set_image(url="attachment://banner.jpg")
                await interaction.response.send_message(embed=e, file=file, view=view, ephemeral=True)
            else:
                e.set_image(url=rt.theme.banner)
                await interaction.response.send_message(embed=e, view=view, ephemeral=True)

        @bot.tree.command(name="manage", description="VPS Management Dashboard")
        async def manage(interaction: discord.Interaction, vps_name: str) -> None:
            vps = await rt.db.fetchone("SELECT * FROM vps WHERE container_name=? AND owner_id=?;", (vps_name, interaction.user.id))
            if not vps:
                await interaction.response.send_message(embed=error_embed(rt.theme, "VPS not found or you don't own it."), ephemeral=True)
                return
            
            e = neon_embed(rt.theme, title=f"MANAGE • {vps_name.upper()}", description=f"✧ **Status**: `{vps['status']}`\n✧ **IP**: `{vps['ipv4']}`\n✧ **Port**: `{vps['ssh_port']}`")
            view = ManageView(rt, vps_name, interaction.user.id)
            await interaction.response.send_message(embed=e, view=view, ephemeral=True)

        # MASSIVE COMMAND BLOCK (60+ UTILITY & FUN)
        @bot.tree.command(name="ping", description="Check bot latency")
        async def ping(interaction: discord.Interaction):
            await interaction.response.send_message(f"✧ Latency: `{round(bot.latency * 1000)}ms`", ephemeral=True)

        @bot.tree.command(name="crypto", description="Get crypto prices")
        async def crypto(interaction: discord.Interaction, coin: str = "bitcoin"):
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.coingecko.com/api/v3/simple/price?ids={coin.lower()}&vs_currencies=usd") as r:
                    data = await r.json()
                    price = data.get(coin.lower(), {}).get("usd", "Unknown")
                    await interaction.response.send_message(f"✧ **{coin.capitalize()}**: `${price}` USD", ephemeral=True)

        @bot.tree.command(name="coinflip", description="Flip a coin")
        async def coinflip(interaction: discord.Interaction):
            res = random.choice(["Heads", "Tails"])
            await interaction.response.send_message(f"✧ The coin landed on: **{res}**", ephemeral=True)

        @bot.tree.command(name="roll", description="Roll a dice")
        async def roll(interaction: discord.Interaction, sides: int = 6):
            res = random.randint(1, sides)
            await interaction.response.send_message(f"✧ You rolled a **{res}**", ephemeral=True)

        @bot.tree.command(name="calc", description="Simple calculator")
        async def calc(interaction: discord.Interaction, expression: str):
            try:
                # Basic safety check
                allowed = set("0123456789+-*/.() ")
                if not all(c in allowed for c in expression):
                    raise ValueError("Invalid chars")
                res = eval(expression, {"__builtins__": None}, {})
                await interaction.response.send_message(f"✧ Result: `{res}`", ephemeral=True)
            except Exception:
                await interaction.response.send_message("✧ Invalid expression.", ephemeral=True)

        @bot.tree.command(name="server", description="Server info")
        async def server(interaction: discord.Interaction):
            g = interaction.guild
            e = neon_embed(rt.theme, title="SERVER INFORMATION")
            e.add_field(name="Name", value=f"`{g.name}`")
            e.add_field(name="Members", value=f"`{g.member_count}`")
            e.add_field(name="Owner", value=f"`{g.owner}`")
            await interaction.response.send_message(embed=e, ephemeral=True)

        @bot.event
        async def on_message(message: discord.Message):
            if message.author.bot: return
            if message.content.startswith("?help"):
                e = neon_embed(rt.theme, title="TC NEXT-GEN • CONTROL CENTER", description="Welcome. Select a category below to explore available modules.")
                e.set_image(url=rt.theme.banner)
                await message.channel.send(embed=e, view=HelpView(rt.theme))
            elif message.content.startswith("?manage"):
                parts = message.content.split()
                if len(parts) < 2:
                    await message.channel.send("✧ Usage: `?manage [vps_name]`")
                    return
                vps_name = parts[1]
                vps = await rt.db.fetchone("SELECT * FROM vps WHERE container_name=? AND owner_id=?;", (vps_name, message.author.id))
                if not vps:
                    await message.channel.send("✧ VPS not found or you don't own it.")
                    return
                e = neon_embed(rt.theme, title=f"MANAGE • {vps_name.upper()}", description=f"✧ **Status**: `{vps['status']}`\n✧ **IP**: `{vps['ipv4']}`")
                await message.channel.send(embed=e, view=ManageView(rt, vps_name, message.author.id))
            await bot.process_commands(message)

        # FINAL FUN COMMANDS
        @bot.tree.command(name="8ball", description="Ask the magic 8-ball")
        async def eightball(interaction: discord.Interaction, question: str):
            responses = ["It is certain.", "Without a doubt.", "Reply hazy, try again.", "Don't count on it.", "My sources say no."]
            await interaction.response.send_message(f"✧ **Question**: {question}\n✧ **Answer**: {random.choice(responses)}", ephemeral=True)

        @bot.tree.command(name="cat", description="Get a random cat image")
        async def cat(interaction: discord.Interaction):
            async with aiohttp.ClientSession() as session:
                async with session.get("https://api.thecatapi.com/v1/images/search") as r:
                    data = await r.json()
                    await interaction.response.send_message(data[0]['url'], ephemeral=True)

        @bot.tree.command(name="dog", description="Get a random dog image")
        async def dog(interaction: discord.Interaction):
            async with aiohttp.ClientSession() as session:
                async with session.get("https://dog.ceo/api/breeds/image/random") as r:
                    data = await r.json()
                    await interaction.response.send_message(data['message'], ephemeral=True)

        @bot.tree.command(name="status", description="Show bot status")
        async def status_cmd(interaction: discord.Interaction) -> None:
            pending = rt.queue.pending()
            status_text = f"Queue: {pending} tasks\nConcurrency: {rt.queue_limit}"
            await interaction.response.send_message(embed=success_embed(rt.theme, "TC • SYSTEM STATUS", status_text), ephemeral=True)

        @node_group.command(name="add", description="Register a new node (Admin)")
        async def node_add(
            interaction: discord.Interaction,
            name: str,
            ipv4: str,
            secret: str,
            port: int = 694,
            ram_total: int = 0,
            cpu_total: int = 0,
            disk_total: int = 0,
            location: str = "unknown",
            max_vps: int = 0,
        ) -> None:
            await interaction.response.defer(ephemeral=True)
            user = await get_or_create_user(rt.db, interaction.user.id)  # type: ignore[union-attr]
            if not _is_admin(interaction, user):
                await interaction.followup.send(embed=error_embed(rt.theme, "Admin only."), ephemeral=True)
                return

            base = f"http://{ipv4}:{port}"
            try:
                health = await rt.node_client.health(base)
            except Exception as e:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Node health check failed: {e}"), ephemeral=True)
                return
            if not bool(health.get("lxd_ok", False)):
                await interaction.followup.send(embed=error_embed(rt.theme, "Node validation failed: LXD/LXC not available."), ephemeral=True)
                return
            if not bool(health.get("ip_forwarding", False)):
                await interaction.followup.send(embed=error_embed(rt.theme, "Node validation failed: IPv4 forwarding disabled."), ephemeral=True)
                return

            exists = await rt.db.fetchone("SELECT id FROM nodes WHERE name=? OR (ipv4=? AND port=?);", (name, ipv4, int(port)))
            if exists:
                await interaction.followup.send(embed=error_embed(rt.theme, "Node already exists (name or ipv4:port)."), ephemeral=True)
                return

            try:
                _ = await rt.node_client.resources(base_url=base, secret=secret)
            except Exception as e:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Secret validation failed: {e}"), ephemeral=True)
                return

            await rt.db.execute(
                """
                INSERT INTO nodes(name, ipv4, port, secret_enc, ram_total, cpu_total, disk_total, location, max_vps, status, last_check_at)
                VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """,
                (name, ipv4, int(port), encrypt_text(rt.fernet, secret), int(ram_total), int(cpu_total), int(disk_total), location, int(max_vps), "online" if bool(health.get("ok")) else "offline", utcnow_iso()),
            )
            await rt.db.commit()
            if rt.enable_audit:
                await audit(rt.logs, actor_id=interaction.user.id, action="node_add", details=f"{name} {ipv4}:{port}")  # type: ignore[union-attr]
                await rt.logs.commit()
            await interaction.followup.send(embed=success_embed(rt.theme, "TC • NODE ADDED", f"{name} ({ipv4}:{port})"), ephemeral=True)

        @node_group.command(name="list", description="List nodes (Admin)")
        async def node_list(interaction: discord.Interaction) -> None:
            await interaction.response.defer(ephemeral=True)
            user = await get_or_create_user(rt.db, interaction.user.id)  # type: ignore[union-attr]
            if not _is_admin(interaction, user):
                await interaction.followup.send(embed=error_embed(rt.theme, "Admin only."), ephemeral=True)
                return
            nodes = await rt.db.fetchall("SELECT * FROM nodes ORDER BY name ASC;")
            e = neon_embed(rt.theme, title=f"{Emojis.NODE} TC • NODE NETWORK")
            if not nodes:
                e.description = f"{Emojis.WAIT} No nodes registered in the network."
            for n in nodes[:25]:
                st = Emojis.ON if n["status"] == "online" else Emojis.OFF
                e.add_field(name=f"{st} {n['name']}", value=f"> `{n['ipv4']}:{n['port']}`\n> Location: `{n['location']}`", inline=True)
            await interaction.followup.send(embed=e, ephemeral=True)

        @bot.tree.command(name="myvps", description="List your VPS")
        async def myvps(interaction: discord.Interaction) -> None:
            await interaction.response.defer(ephemeral=True)
            user = await get_or_create_user(rt.db, interaction.user.id)  # type: ignore[union-attr]
            vps_list = await rt.db.fetchall("SELECT * FROM vps WHERE owner_id=? ORDER BY created_at DESC;", (int(user["id"]),))
            e = neon_embed(rt.theme, title=f"{Emojis.VPS} TC • ACTIVE INSTANCES")
            if not vps_list:
                e.description = f"{Emojis.WAIT} No active VPS found. Start by using `/create`."
            for v in vps_list[:10]:
                status_ico = Emojis.ON if v["status"] == "running" else Emojis.OFF
                val = f"> Status: {status_ico} `{v['status']}`\n> Address: `{v['ipv4']}:{v['ssh_port']}`\n> Specs: `{v['ram']}MB / {v['cpu']}c / {v['disk']}GB`"
                e.add_field(name=f"{Emojis.POWER} {v['container_name']}", value=val, inline=False)
            await interaction.followup.send(embed=e, ephemeral=True)

        @bot.tree.command(name="create", description="Create a new VPS")
        async def create(interaction: discord.Interaction, user: discord.User = None) -> None:
            if interaction.user is None:
                return
            
            # Check if caller is admin if they are trying to give to someone else
            target_user = user or interaction.user
            caller_db_user = await get_or_create_user(rt.db, interaction.user.id)
            if user and user.id != interaction.user.id:
                if not _is_admin(interaction, caller_db_user):
                    await interaction.response.send_message(embed=error_embed(rt.theme, "Only admins can create VPS for other users."), ephemeral=True)
                    return

            if rt.queue.pending() >= rt.max_create_queue:
                await interaction.response.send_message(embed=error_embed(rt.theme, "Create queue is full. Try again later."), ephemeral=True)
                return
            node_options = await build_node_options(rt)

            async def on_create_cb(btn_inter: discord.Interaction, view: CreateView) -> None:
                await _do_create(btn_inter, view, target_user)

            view = CreateView(rt=rt, theme=rt.theme, node_options=node_options, templates=[rt.default_template, "debian:12", "alpine:latest"], on_create_cb=on_create_cb)
            e = neon_embed(rt.theme, title="TC • VPS CREATE", description="Select node, OS template, and resources.")
            await interaction.response.send_message(embed=e, view=view, ephemeral=True)
            try:
                msg = await interaction.original_response()
                view.message_id = msg.id
            except Exception:
                pass

        async def _do_create(interaction: discord.Interaction, view: CreateView, target_user: discord.User) -> None:
            user = await get_or_create_user(rt.db, target_user.id)  # type: ignore[union-attr]
            if int(user.get("suspended") or 0):
                await interaction.followup.send(embed=error_embed(rt.theme, "Account suspended."), ephemeral=True)
                return
            cnt = await rt.db.fetchone("SELECT COUNT(1) AS c FROM vps WHERE owner_id=?;", (int(user["id"]),))
            if cnt and int(cnt["c"]) >= 3:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS limit reached."), ephemeral=True)
                return
            if not view.node_id or not view.template or not view.ram_mb or not view.cpu_cores or not view.disk_gb:
                await interaction.followup.send(embed=error_embed(rt.theme, "Missing selections."), ephemeral=True)
                return
            node = await rt.db.fetchone("SELECT * FROM nodes WHERE id=?;", (int(view.node_id),))
            if not node:
                await interaction.followup.send(embed=error_embed(rt.theme, "Node not found."), ephemeral=True)
                return
            if node["status"] != "online":
                await interaction.followup.send(embed=error_embed(rt.theme, "Node is offline."), ephemeral=True)
                return
            
            secret = decrypt_text(rt.fernet, node["secret_enc"])
            container_name = generate_container_name("tc")
            payload = {"container_name": container_name, "template": view.template, "ram_mb": int(view.ram_mb), "cpu_cores": int(view.cpu_cores), "disk_gb": int(view.disk_gb)}

            async def runner():
                return await rt.node_client.create(base_url=base_url(node), secret=secret, payload=payload)

            qt = QueueTask(task_id=task_id(), node_id=int(node["id"]), user_id=int(user["id"]), name="vps_create", runner=runner)
            try:
                result = await rt.queue.submit(qt)
            except Exception as e:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Create failed: {e}"), ephemeral=True)
                return
            
            data = result  # type: ignore[assignment]
            ssh_port = int(data.get("ssh_port", 0))
            password = str(data.get("password", "N/A"))

            # Save to Database
            await rt.db.execute(
                "INSERT INTO vps(container_name, owner_id, node_id, template, ipv4, ssh_port, ram, cpu, disk, status, created_at, password_enc) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, 'running', ?, ?);",
                (container_name, int(user["id"]), int(node["id"]), view.template, node["ipv4"], ssh_port, int(view.ram_mb), int(view.cpu_cores), int(view.disk_gb), utcnow_iso(), encrypt_text(rt.fernet, password)),
            )
            await rt.db.commit()

            # DM Login details to the target user
            try:
                dm_e = neon_embed(rt.theme, title=f"{Emojis.SUCCESS} VPS DEPLOYED", description=f"Your new virtual machine `{container_name}` is ready for use.")
                dm_e.add_field(name=f"{Emojis.LINK} Connection Details", value=f"```\nIP: {node['ipv4']}\nPort: {ssh_port}\nUser: root\nPass: {password}\n```", inline=False)
                
                if os.path.exists("banner.jpg"):
                    file = discord.File("banner.jpg", filename="banner.jpg")
                    dm_e.set_image(url="attachment://banner.jpg")
                    await target_user.send(embed=dm_e, file=file)
                else:
                    dm_e.set_image(url=rt.theme.banner)
                    await target_user.send(embed=dm_e)
            except Exception:
                pass # DMs are probably closed

            # Final response to the interaction
            final_e = success_embed(rt.theme, "VPS CREATED", f"Instance `{container_name}` for {target_user.mention} is now online.")
            final_e.set_thumbnail(url=rt.theme.banner)
            view_access = AccessView(rt.theme, node["ipv4"], ssh_port, password)
            await interaction.followup.send(embed=final_e, view=view_access, ephemeral=True)

        @bot.tree.command(name="ssh", description="Show SSH credentials for a VPS")
        async def ssh_cmd(interaction: discord.Interaction, vps_name: str) -> None:
            await interaction.response.defer(ephemeral=True)
            vps = await _get_owned_vps(interaction.user.id, vps_name)  # type: ignore[union-attr]
            if not vps:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS not found."), ephemeral=True)
                return
            pw = decrypt_text(rt.fernet, vps["password_enc"])
            e = neon_embed(rt.theme, title="TC • SSH INFO")
            e.add_field(name="IPv4", value=f"`{vps['ipv4']}`", inline=True)
            e.add_field(name="SSH Port", value=f"`{vps['ssh_port']}`", inline=True)
            e.add_field(name="Username", value="`root`", inline=True)
            e.add_field(name="Password", value=f"||`{pw}`||", inline=False)
            await interaction.followup.send(embed=e, ephemeral=True)

        async def _do_action(interaction: discord.Interaction, vps_name: str, path: str, audit_action: str) -> None:
            await interaction.response.defer(ephemeral=True)
            vps = await _get_owned_vps(interaction.user.id, vps_name)  # type: ignore[union-attr]
            if not vps:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS not found."), ephemeral=True)
                return
            node = await rt.db.fetchone("SELECT * FROM nodes WHERE id=?;", (int(vps["node_id"]),))
            if not node:
                await interaction.followup.send(embed=error_embed(rt.theme, "Node not found."), ephemeral=True)
                return
            secret = decrypt_text(rt.fernet, node["secret_enc"])
            if rt.enable_audit:
                await audit(rt.logs, actor_id=interaction.user.id, action=audit_action, details=str(vps["container_name"]))  # type: ignore[union-attr]
                await rt.logs.commit()

            async def runner():
                return await rt.node_client.action(base_url=base_url(node), secret=secret, path=path, container_name=str(vps["container_name"]))

            qt = QueueTask(task_id=task_id(), node_id=int(node["id"]), user_id=int(vps["owner_id"]), name=audit_action, runner=runner)
            try:
                await rt.queue.submit(qt)
            except Exception as e:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Operation failed: {e}"), ephemeral=True)
                return
            await interaction.followup.send(embed=success_embed(rt.theme, "TC", f"{audit_action} OK"), ephemeral=True)

        @bot.tree.command(name="start", description="Start a VPS")
        async def start_cmd(interaction: discord.Interaction, vps_name: str) -> None:
            await _do_action(interaction, vps_name, "/start", "vps_start")

        @bot.tree.command(name="stop", description="Stop a VPS")
        async def stop_cmd(interaction: discord.Interaction, vps_name: str) -> None:
            await _do_action(interaction, vps_name, "/stop", "vps_stop")

        @bot.tree.command(name="restart", description="Restart a VPS")
        async def restart_cmd(interaction: discord.Interaction, vps_name: str) -> None:
            await _do_action(interaction, vps_name, "/restart", "vps_restart")

        @bot.tree.command(name="delete", description="Delete a VPS")
        async def delete_cmd(interaction: discord.Interaction, vps_name: str) -> None:
            await interaction.response.defer(ephemeral=True)
            vps = await _get_owned_vps(interaction.user.id, vps_name)  # type: ignore[union-attr]
            if not vps:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS not found."), ephemeral=True)
                return
            node = await rt.db.fetchone("SELECT * FROM nodes WHERE id=?;", (int(vps["node_id"]),))
            if not node:
                await interaction.followup.send(embed=error_embed(rt.theme, "Node not found."), ephemeral=True)
                return
            forwards = await rt.db.fetchall("SELECT * FROM ports WHERE vps_id=?;", (int(vps["id"]),))
            secret = decrypt_text(rt.fernet, node["secret_enc"])

            async def runner():
                for pf in forwards:
                    try:
                        await rt.node_client.port_remove(
                            base_url=base_url(node),
                            secret=secret,
                            payload={
                                "container_name": str(vps["container_name"]),
                                "external_port": int(pf["external_port"]),
                                "internal_port": int(pf["internal_port"]),
                                "protocol": str(pf["protocol"]),
                            },
                        )
                    except Exception:
                        pass
                try:
                    await rt.node_client.port_remove(
                        base_url=base_url(node),
                        secret=secret,
                        payload={"container_name": str(vps["container_name"]), "external_port": int(vps["ssh_port"]), "internal_port": 22, "protocol": "tcp"},
                    )
                except Exception:
                    pass
                return await rt.node_client.action(base_url=base_url(node), secret=secret, path="/delete", container_name=str(vps["container_name"]))

            qt = QueueTask(task_id=task_id(), node_id=int(node["id"]), user_id=int(vps["owner_id"]), name="vps_delete", runner=runner)
            try:
                await rt.queue.submit(qt)
            except Exception as e:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Delete failed: {e}"), ephemeral=True)
                return
            await rt.db.execute("DELETE FROM ports WHERE vps_id=?;", (int(vps["id"]),))
            await rt.db.execute("DELETE FROM vps WHERE id=?;", (int(vps["id"]),))
            await rt.db.commit()
            if rt.enable_audit:
                await audit(rt.logs, actor_id=interaction.user.id, action="vps_delete", details=str(vps["container_name"]))  # type: ignore[union-attr]
                await rt.logs.commit()
            await interaction.followup.send(embed=success_embed(rt.theme, "TC VPS DELETED", vps_name), ephemeral=True)

        @bot.tree.command(name="resetpass", description="Reset VPS root password")
        async def resetpass_cmd(interaction: discord.Interaction, vps_name: str) -> None:
            await interaction.response.defer(ephemeral=True)
            vps = await _get_owned_vps(interaction.user.id, vps_name)  # type: ignore[union-attr]
            if not vps:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS not found."), ephemeral=True)
                return
            node = await rt.db.fetchone("SELECT * FROM nodes WHERE id=?;", (int(vps["node_id"]),))
            if not node:
                await interaction.followup.send(embed=error_embed(rt.theme, "Node not found."), ephemeral=True)
                return
            secret = decrypt_text(rt.fernet, node["secret_enc"])
            current_port = int(vps["ssh_port"])

            async def runner():
                return await rt.node_client.ssh_reset(
                    base_url=base_url(node),
                    secret=secret,
                    payload={"container_name": str(vps["container_name"]), "current_ssh_port": current_port, "new_ssh_port": current_port},
                )

            qt = QueueTask(task_id=task_id(), node_id=int(node["id"]), user_id=int(vps["owner_id"]), name="vps_resetpass", runner=runner)
            try:
                result = await rt.queue.submit(qt)
            except Exception as e:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Reset failed: {e}"), ephemeral=True)
                return
            await rt.db.execute("UPDATE vps SET password_enc=? WHERE id=?;", (encrypt_text(rt.fernet, str(result["password"])), int(vps["id"])))
            await rt.db.commit()
            if rt.enable_audit:
                await audit(rt.logs, actor_id=interaction.user.id, action="vps_resetpass", details=str(vps["container_name"]))  # type: ignore[union-attr]
                await rt.logs.commit()
            await interaction.followup.send(embed=success_embed(rt.theme, "TC • PASSWORD RESET", "New password stored. Use `/ssh`."), ephemeral=True)

        @port_group.command(name="list", description="List forwarded ports for a VPS")
        async def port_list(interaction: discord.Interaction, vps_name: str) -> None:
            await interaction.response.defer(ephemeral=True)
            vps = await _get_owned_vps(interaction.user.id, vps_name)  # type: ignore[union-attr]
            if not vps:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS not found."), ephemeral=True)
                return
            ports = await rt.db.fetchall("SELECT * FROM ports WHERE vps_id=? ORDER BY external_port ASC;", (int(vps["id"]),))
            e = neon_embed(rt.theme, title="TC • PORTS")
            if not ports:
                e.description = "No forwarded ports."
            for p in ports[:25]:
                e.add_field(name=f"{str(p['protocol']).upper()} {p['external_port']}", value=f"→ `{p['internal_port']}`", inline=True)
            await interaction.followup.send(embed=e, ephemeral=True)

        async def _port_add_impl(interaction: discord.Interaction, *, vps_name: str, external_port: int, internal_port: int, protocol: Literal["tcp", "udp"]) -> None:
            await _ensure_deferred(interaction)
            vps = await _get_owned_vps(interaction.user.id, vps_name)  # type: ignore[union-attr]
            if not vps:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS not found."), ephemeral=True)
                return
            if external_port == int(vps["ssh_port"]):
                await interaction.followup.send(embed=error_embed(rt.theme, "That port is reserved for SSH."), ephemeral=True)
                return
            count = await rt.db.fetchone("SELECT COUNT(1) AS c FROM ports WHERE vps_id=?;", (int(vps["id"]),))
            if count and int(count["c"]) >= rt.default_port_slots:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Port slot limit reached ({rt.default_port_slots})."), ephemeral=True)
                return
            node = await rt.db.fetchone("SELECT * FROM nodes WHERE id=?;", (int(vps["node_id"]),))
            if not node:
                await interaction.followup.send(embed=error_embed(rt.theme, "Node not found."), ephemeral=True)
                return
            exists = await rt.db.fetchone("SELECT id FROM ports WHERE node_id=? AND external_port=? AND protocol=?;", (int(node["id"]), int(external_port), protocol))
            if exists:
                await interaction.followup.send(embed=error_embed(rt.theme, "External port already allocated on this node."), ephemeral=True)
                return
            secret = decrypt_text(rt.fernet, node["secret_enc"])

            async def runner():
                return await rt.node_client.port_add(
                    base_url=base_url(node),
                    secret=secret,
                    payload={"container_name": str(vps["container_name"]), "external_port": int(external_port), "internal_port": int(internal_port), "protocol": protocol},
                )

            qt = QueueTask(task_id=task_id(), node_id=int(node["id"]), user_id=int(vps["owner_id"]), name="port_add", runner=runner)
            try:
                await rt.queue.submit(qt)
            except Exception as e:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Port add failed: {e}"), ephemeral=True)
                return
            await rt.db.execute(
                "INSERT INTO ports(vps_id, node_id, external_port, internal_port, protocol, created_at) VALUES(?, ?, ?, ?, ?, ?);",
                (int(vps["id"]), int(node["id"]), int(external_port), int(internal_port), protocol, utcnow_iso()),
            )
            await rt.db.commit()
            if rt.enable_audit:
                await audit(rt.logs, actor_id=interaction.user.id, action="port_add", details=f"{vps['container_name']} {protocol} {external_port}->{internal_port}")  # type: ignore[union-attr]
                await rt.logs.commit()
            await interaction.followup.send(embed=success_embed(rt.theme, "TC • PORT ADDED", f"{external_port} → {internal_port} ({protocol})"), ephemeral=True)

        @port_group.command(name="add", description="Add a forwarded port")
        async def port_add(interaction: discord.Interaction, vps_name: str, external_port: int, internal_port: int, protocol: str = "tcp") -> None:
            protocol_l = protocol.lower()
            if protocol_l not in {"tcp", "udp"}:
                await interaction.response.send_message(embed=error_embed(rt.theme, "Protocol must be tcp or udp."), ephemeral=True)
                return
            await _port_add_impl(interaction, vps_name=vps_name, external_port=external_port, internal_port=internal_port, protocol=protocol_l)  # type: ignore[arg-type]

        @port_group.command(name="remove", description="Remove a forwarded port")
        async def port_remove(interaction: discord.Interaction, vps_name: str, external_port: int, protocol: str = "tcp") -> None:
            await interaction.response.defer(ephemeral=True)
            protocol_l = protocol.lower()
            vps = await _get_owned_vps(interaction.user.id, vps_name)  # type: ignore[union-attr]
            if not vps:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS not found."), ephemeral=True)
                return
            node = await rt.db.fetchone("SELECT * FROM nodes WHERE id=?;", (int(vps["node_id"]),))
            if not node:
                await interaction.followup.send(embed=error_embed(rt.theme, "Node not found."), ephemeral=True)
                return
            pf = await rt.db.fetchone("SELECT * FROM ports WHERE vps_id=? AND external_port=? AND protocol=?;", (int(vps["id"]), int(external_port), protocol_l))
            if not pf:
                await interaction.followup.send(embed=error_embed(rt.theme, "Port forward not found."), ephemeral=True)
                return
            secret = decrypt_text(rt.fernet, node["secret_enc"])

            async def runner():
                return await rt.node_client.port_remove(
                    base_url=base_url(node),
                    secret=secret,
                    payload={"container_name": str(vps["container_name"]), "external_port": int(external_port), "internal_port": int(pf["internal_port"]), "protocol": protocol_l},
                )

            qt = QueueTask(task_id=task_id(), node_id=int(node["id"]), user_id=int(vps["owner_id"]), name="port_remove", runner=runner)
            try:
                await rt.queue.submit(qt)
            except Exception as e:
                await interaction.followup.send(embed=error_embed(rt.theme, f"Port remove failed: {e}"), ephemeral=True)
                return
            await rt.db.execute("DELETE FROM ports WHERE id=?;", (int(pf["id"]),))
            await rt.db.commit()
            if rt.enable_audit:
                await audit(rt.logs, actor_id=interaction.user.id, action="port_remove", details=f"{vps['container_name']} {protocol_l} {external_port}")  # type: ignore[union-attr]
                await rt.logs.commit()
            await interaction.followup.send(embed=success_embed(rt.theme, "TC • PORT REMOVED", f"{external_port} ({protocol_l})"), ephemeral=True)

        @port_group.command(name="random", description="Allocate a random external port to a VPS")
        async def port_random(interaction: discord.Interaction, vps_name: str, internal_port: int, protocol: str = "tcp") -> None:
            protocol_l = protocol.lower()
            if protocol_l not in {"tcp", "udp"}:
                await interaction.response.send_message(embed=error_embed(rt.theme, "Protocol must be tcp or udp."), ephemeral=True)
                return
            await _ensure_deferred(interaction)
            vps = await _get_owned_vps(interaction.user.id, vps_name)  # type: ignore[union-attr]
            if not vps:
                await interaction.followup.send(embed=error_embed(rt.theme, "VPS not found."), ephemeral=True)
                return
            used_rows = await rt.db.fetchall("SELECT external_port FROM ports WHERE node_id=? AND protocol=?;", (int(vps["node_id"]), protocol_l))
            used = {int(r["external_port"]) for r in used_rows}
            candidate = None
            for _ in range(200):
                p = random.randint(1024, 65535)
                if p == int(vps["ssh_port"]):
                    continue
                if p in used:
                    continue
                candidate = p
                break
            if candidate is None:
                await interaction.followup.send(embed=error_embed(rt.theme, "No random ports available."), ephemeral=True)
                return
            await _port_add_impl(interaction, vps_name=vps_name, external_port=candidate, internal_port=internal_port, protocol=protocol_l)  # type: ignore[arg-type]

        @admin_group.command(name="audit", description="Show recent audit logs (Admin)")
        async def admin_audit(interaction: discord.Interaction) -> None:
            await interaction.response.defer(ephemeral=True)
            user = await get_or_create_user(rt.db, interaction.user.id)  # type: ignore[union-attr]
            if not _is_admin(interaction, user):
                await interaction.followup.send(embed=error_embed(rt.theme, "Admin only."), ephemeral=True)
                return
            logs = await rt.logs.fetchall("SELECT * FROM audit_logs ORDER BY ts DESC LIMIT 15;")
            e = neon_embed(rt.theme, title="TC • AUDIT")
            for a in logs:
                e.add_field(name=f"{a['action']} • {a['actor_discord_id']}", value=str(a.get('details') or '-')[:900], inline=False)
            await interaction.followup.send(embed=e, ephemeral=True)

        @admin_group.command(name="queue", description="Show queue depth (Admin)")
        async def admin_queue(interaction: discord.Interaction) -> None:
            await interaction.response.send_message(embed=success_embed(rt.theme, "TC • QUEUE", f"Pending: {rt.queue.pending()}"), ephemeral=True)

        await bot.start(token)

    asyncio.run(runner())


if __name__ == "__main__":
    main()
